
let secretNumber = Math.floor(Math.random() * 4501) + 500;

let totalGuesses = 0;
let maxGuesses = 5;

let guessInput = document.getElementById("guessInput");
let submitButton = document.getElementById("submitButton");
let textDisplay = document.getElementById("labelid");

let gameOver = false;

submitButton.addEventListener("click", checkGuess);

function checkGuess()
{
    if (gameOver)
    {
        return;
    }

    let userGuess = guessInput.value.trim();

    // Validate the user's input
    if 
    (userGuess === "" || isNaN(Number(userGuess)) || !Number.isInteger(Number(userGuess)) ||Number(userGuess) < 500 || Number(userGuess) > 5000)
    {
        textDisplay.textContent =
            "Please enter a valid whole number between 500 and 5000.";
        return;
    }

    userGuess = Number(userGuess);

    totalGuesses++;

    let feedbackMessage;

    if (userGuess > secretNumber)
    {
        feedbackMessage = "Too high!";
    }
    else if (userGuess < secretNumber)
    {
        feedbackMessage = "Too low!";
    }
    else
    {
        feedbackMessage = "Correct!";
        textDisplay.textContent =
            feedbackMessage +
            " You guessed the number in " +
            totalGuesses + " attempt(s).";

        gameOver = true;
        guessInput.disabled = true;
        submitButton.disabled = true;

        return;
    }

    // Check whether the user has used all 5 attempts
    if (totalGuesses >= maxGuesses)
    {
        textDisplay.textContent =
            feedbackMessage +
            " Out of guesses! The secret number was " +
            secretNumber + ".";

        gameOver = true;
        guessInput.disabled = true;
        submitButton.disabled = true;
    }
    else
    {
        textDisplay.textContent =
            feedbackMessage +
            " Attempts used: " + totalGuesses +
            " out of " + maxGuesses + ".";
    }

    // Clear the input field
    guessInput.value = "";
}
