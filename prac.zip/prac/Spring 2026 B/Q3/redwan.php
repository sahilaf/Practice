<?php

    $servername = "localhost"; /// 127.0.0.1
    $username = "root";
    $password = "";
    $dbname = "uiu_bookshop";
    $port = "3306" ;
    $conn = new mysqli($servername, $username, $password, $dbname, $port);
    

    if ($conn->connect_error) 
    {
        die("Connection failed: " . $conn->connect_error);
    }
    else 
        {
            echo "<h3>Connection Successfull</h3>" ;
        }





    
    echo "<h3>Query 1</h3>" ;


    $sql1= "SELECT `BookTitle` , `Price`
            FROM `book_info` 
            WHERE Category = 'Programming'
            ORDER BY Price DESC" ;
    $result = $conn->query($sql1);

    while($row = $result->fetch_assoc()) 
    {
        echo "Book Title: " . $row["BookTitle"]. " - Price: " . $row["Price"]. " " . "<br>" ;
    }







    echo "<h3>Query 2</h3>" ;


    $sql2= "SELECT `BookTitle`, `Author`, `Price` 
            FROM `book_info` 
            WHERE Price > 400 AND Category = 'Programming'" ;
    $result = $conn->query($sql2);

    while($row = $result->fetch_assoc()) 
    {
        echo "Book Title: " . $row["BookTitle"]. " - Author: " . $row["Author"]. " - Price:  " . $row["Price"]. " " . "<br>" ;
    }

    
  








    echo "<h3>Query 3</h3>" ;


    $sql3= "SELECT `Category`, COUNT(*) AS noOfBooks 
            FROM `book_info` 
            GROUP BY Category" ;
    $result = $conn->query($sql3);

    while($row = $result->fetch_assoc()) 
    {
        echo "Category : " . $row["Category"]. " - Number of books : " . $row["noOfBooks"]. " " . "<br>" ;
    }



    



     echo "<h3>Query 4</h3>" ;


    $sql4= "SELECT SUM(Stock*Price) AS totalSum
            FROM `book_info` 
            WHERE 1" ;
    $result = $conn->query($sql4);   

     while($row = $result->fetch_assoc()) 
    {
        echo "Net Worth : " . $row["totalSum"]. " " . "<br>" ;
    }



    
     echo "<h3>Query 5</h3>" ;


    $sql5= "UPDATE `book_info` 
            SET `Price`= (Price - (Price*0.1))
            WHERE Category = 'Language'" ;

    
    $sql6= "SELECT `BookTitle`, `Price`
            FROM `book_info` 
            WHERE Category = 'Language'" ;




    $result = $conn->query($sql6);   

     while($row = $result->fetch_assoc()) 
    {
        echo "Book title  : " . $row["BookTitle"]. " - Updated price: " . $row["BookTitle"]. " " . "<br>" ;
    }



       




?>