<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Spring 2026, Set B </title>
</head>
<body>
    <h1>UIU Mars Rover Team</h1>

    <form action="" method="post">
        Mission distance in meters : <input type="number" name="missionDistanceInMeter"> <br> <br>
        Energy consumption per meter : <input type="number" name="energyConsumptionPerMeter"> <br> <br>
        Capacity of one battery module : <input type="number" name="capacityOfOneBatteryModule"> <br> <br> <br> <br>

        <button name="submit">Submit</button>
    </form>
    
    <?php

        if(isset($_POST["submit"]))
            {
                $missionDistanceInMeter = $_POST["missionDistanceInMeter"] ;
                $energyConsumptionPerMeter = $_POST["energyConsumptionPerMeter"] ;
                $capacityOfOneBatteryModule = $_POST["capacityOfOneBatteryModule"] ;
               


                $totalEnergyRequired = $missionDistanceInMeter * $energyConsumptionPerMeter ;
                
            
                echo "Total credit earned:  $totalEnergyRequired <br>" ;
        

                $minimumNumberOfModules =  ceil($totalEnergyRequired / $capacityOfOneBatteryModule) ;

                echo "Total number of battery modules :  $minimumNumberOfModules <br>" ;


                $unusedEnergy = ($minimumNumberOfModules * $capacityOfOneBatteryModule) - $totalEnergyRequired ;

                echo "Total Unused energy  :  $unusedEnergy <br>" ;

                $totalEnergyCarried = $minimumNumberOfModules * $capacityOfOneBatteryModule ;

                $percentageOfUnusedEnergy = (($unusedEnergy * 100)/$totalEnergyCarried) ;


                if ($percentageOfUnusedEnergy <= 10)
                    {
                        $status = "Efficient" ;
                    }
                else if ($percentageOfUnusedEnergy > 100 && $percentageOfUnusedEnergy <= 25) 
                    {
                        $status = "Acceptable " ;
                    }
                else if ($percentageOfUnusedEnergy > 25)
                    {
                        $status = "Wasteful" ;
                    }    
                   
                echo "$status <br>" ;    



            }



    ?>



</body>
</html>