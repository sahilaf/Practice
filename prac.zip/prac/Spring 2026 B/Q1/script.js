
let arrayForHeartRate = [];
let arrayForOxygenSaturation = [];
let i = 0;

let heartRateInput = document.getElementById("heartRateInput");
let oxygenSaturationInput = document.getElementById("oxygenSaturationInput");
let addButton = document.getElementById("addButton");
let textDisplay = document.getElementById("labelid");

addButton.addEventListener("click", calculator);

function calculator() {

    let heartRate = heartRateInput.value.trim();
    let oxygenSaturation = oxygenSaturationInput.value.trim();

    if (
        heartRate === "" ||
        isNaN(Number(heartRate)) ||
        Number(heartRate) < 0
    ) {
        textDisplay.textContent = "Please enter a valid Heart Rate.";
        return;
    }

    if (
        oxygenSaturation === "" ||
        isNaN(Number(oxygenSaturation)) ||
        Number(oxygenSaturation) < 0 ||
        Number(oxygenSaturation) > 100
    ) {
        textDisplay.textContent =
            "Please enter a valid Oxygen Saturation (0-100).";
        return;
    }

    heartRate = Number(heartRate);
    oxygenSaturation = Number(oxygenSaturation);

    arrayForHeartRate[i] = heartRate;
    arrayForOxygenSaturation[i] = oxygenSaturation;
    i++;

    let sumOfHeartRate = 0;
    let sumOfOxygenSaturation = 0;

    for (let j = 0; j < i; j++) {
        sumOfHeartRate += arrayForHeartRate[j];
        sumOfOxygenSaturation += arrayForOxygenSaturation[j];
    }

    let averageHeartRate = sumOfHeartRate / i;
    let averageOxygenSaturation = sumOfOxygenSaturation / i;

    let riskScore =
        ((100 - oxygenSaturation) * 2) +
        (Math.abs(heartRate - 80) * 0.5);

    let feedbackMessage;

    if (riskScore <= 10) {
        feedbackMessage = "SAFE";
    } else if (riskScore <= 20) {
        feedbackMessage = "WARNING";
    } else {
        feedbackMessage = "DANGER";
    }

    
    textDisplay.textContent =
        "Average Heart Rate: " + averageHeartRate.toFixed(2) +
        "\nAverage Oxygen Saturation: " +
        averageOxygenSaturation.toFixed(2) +
        "\nRisk Score: " + riskScore.toFixed(2) +
        "\nFeedback: " + feedbackMessage;

    
    

    
    heartRateInput.value = "";
    oxygenSaturationInput.value = "";
}
