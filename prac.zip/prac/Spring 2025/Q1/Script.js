const target = 100 ; 
 
let totalScore = 0; 
let totalEntries = 0 ;
 
let passwordInput = document.getElementById("passwordInput"); 
let addButton = document.getElementById("addButton"); 
let textDisplay = document.getElementById("labelid"); 


if (totalEntries>8)
{
    let message = "You need more Practice.";
    textDisplay.textContent = "" + message ;
    
}
 
addButton.addEventListener("click", checkStrength); 
 
function checkStrength() { 
     
    let password = passwordInput.value.trim(); 
 
    if (password.length < 6) 
    { 
        totalEntries++ ;
        textDisplay.textContent = "Minimum 6 characters are required. "; 
        return; 
    } 

    let count = 0 ;
 
    for (let i = 0 ; i < password.length ; i++)
    {
        count++ ;

        if (password[i] >= 'A' && password[i] <= 'Z')
        {
            totalScore + totalScore + 15 ;
        }

        if (password[i] >= 'a' && password[i] <= 'z')
        {
             totalScore + totalScore + 15 ;
        }

        if (password[i] >= '0' && password[i] <= '9')
        {
             totalScore + totalScore + 20 ;
        }

        if (password[i] === '!' || password[i] === '$' || password[i] === '@' || password[i] === '#' || password[i] === '%' || password[i] === '^' || password[i] === '&' || password[i] === '*')
        {
             totalScore + totalScore + 25 ;
        }

    }

    let res = count/2 ;
    totalScore = (totalScore + (res*10)) ;
 
    let feedbackMessage; 
 
    if (totalScore > 100) 
    {
        feedbackMessage = "Perfect Password. Seccess !!";
    } 
    else if (totalScore >= 0 && totalScore <= 30) 
    { 
        feedbackMessage = "Very weak"; 
        totalEntries++ ;

    } 
    else if (totalScore >= 31 && totalScore <= 50) 
    { 
        feedbackMessage = "Week";
        totalEntries++ ;
 
    } 
    else if (totalScore >= 51 && totalScore <= 70) 
    { 
        feedbackMessage = "Medium ";
        totalEntries++ ;
 
    }
    else if (totalScore >= 71 && totalScore <= 90) 
    { 
        feedbackMessage = "Strong "; 
    } 
    else if (totalScore >= 91 && totalScore <= 100) 
    { 
        feedbackMessage = "Very strong"; 
    }  
     
 
    textDisplay.textContent = 
        "Feedback : " + feedbackMessage ; 

    totalScore = 0 ;    
    passwordInput.value = ""; 
}