<?php

    $servername = "localhost"; /// 127.0.0.1
    $username = "root";
    $password = "";
    $dbname = "uiutech_final";
    $port = "3306" ;
    $conn = new mysqli($servername, $username, $password, $dbname, $port);
    

    if ($conn->connect_error) 
    {
        die("Connection failed: " . $conn->connect_error);
    }
    else 
        {
            echo "<h3>Connection Successfull</h3>" ;
        }




    
    echo "<h3>Query 1</h3>" ;


    $sql1= "SELECT `PerformanceRating` , COUNT(EmployeeID) AS Count FROM `employee_final` GROUP BY PerformanceRating" ;
    $result = $conn->query($sql1);

    while($row = $result->fetch_assoc()) 
    {
        echo "PR: " . $row["PerformanceRating"]. " - Name: " . $row["Count"]. " " . "<br>";
    }







    echo "<h3>Query 2</h3>" ;


    $sql2= "UPDATE `employee_final` SET `PerformanceRating`='C' WHERE Salary < 40000 and PerformanceRating <> 'D'" ;
    $result = $conn->query($sql2);


   $sql = "SELECT * FROM `employee_final` WHERE 1";

    $result = $conn->query($sql);
    
        while($row = $result->fetch_assoc()) 
        {
            echo " " . $row["EmployeeID"]. " " . $row["EmployeeName"]. " " . $row["DepartmentID"]. " " . $row["DepartmentName"]. " " . $row["Salary"]. " " . $row["PerformanceRating"]."<br>";
        }








    echo "<h3>Query 3</h3>" ;


    $sql3= "UPDATE `employee_final` SET `Salary`= Salary + 5000 WHERE Salary > 50000 and Salary+5000 <= 60000" ;
    $result = $conn->query($sql3);

    $sql = "SELECT * FROM `employee_final` WHERE 1";

    $result = $conn->query($sql);
    
        while($row = $result->fetch_assoc()) 
        {
            echo " " . $row["EmployeeID"]. " " . $row["EmployeeName"]. " " . $row["DepartmentID"]. " " . $row["DepartmentName"]. " " . $row["Salary"]. " " . $row["PerformanceRating"]."<br>";
        }


    



     echo "<h3>Query 4</h3>" ;


    $sql4= "SELECT `DepartmentName` , COUNT(EmployeeID) as Countt FROM `employee_final` GROUP BY DepartmentName ORDER BY Countt DESC" ;
    $result = $conn->query($sql4);   

    $sql = "SELECT * FROM `employee_final` WHERE 1";

    $result = $conn->query($sql);
    
        while($row = $result->fetch_assoc()) 
        {
            echo " " . $row["EmployeeID"]. " " . $row["EmployeeName"]. " " . $row["DepartmentID"]. " " . $row["DepartmentName"]. " " . $row["Salary"]. " " . $row["PerformanceRating"]."<br>";
        }



       




?>