<?php

    $servername = "localhost"; /// 127.0.0.1
    $username = "root";
    $password = "";
    $dbname = "tourism";
    $port = "3306" ;
    $conn = new mysqli($servername, $username, $password, $dbname, $port);
    

    if ($conn->connect_error) 
    {
        die("Connection failed: " . $conn->connect_error);
    }
    else 
        {
            echo "<h3>Connection Successfull</h3>" ;
        }



    
    echo "<h3>Query 1</h3>" ;


    $sql1= "SELECT `SpotName`, `Region`, `Rating` 
            FROM `tourist_spot` 
            WHERE Rating > 4.5 OR SpotName LIKE '%Beach%'
            ORDER BY Rating DESC" ;
    $result = $conn->query($sql1);

    while($row = $result->fetch_assoc()) 
    {
        echo "Spot Name: " . $row["SpotName"]. " - Region: " . $row["Region"]. " - Rating: " . $row["Rating"] . " " . "<br>";
    }







    echo "<h3>Query 2</h3>" ;


    $sql2= "UPDATE `tourist_spot` 
            SET `Rating`= Rating + 0.2 , `EntryFee`= (EntryFee + (0.1*EntryFee)) 
            WHERE Rating > 4.0 AND Rating <= 4.5 and EntryFee > 0" ;
    $result = $conn->query($sql2);


   $sql = "SELECT * FROM `tourist_spot` WHERE 1";

    $result = $conn->query($sql);
    
        while($row = $result->fetch_assoc()) 
        {
            echo " " . $row["SpotID"]. " - " . $row["SpotName"]. " - " . $row["Region"]. " - " . $row["Category"]. " - " . $row["Rating"]. " - " . $row["EntryFee"]. " - " . $row["VisitorsPerYear"]."<br>";
        }








    echo "<h3>Query 3</h3>" ;


    $sql3= "SELECT `Category` , COUNT(*) AS NoOfSpots , AVG(Rating) AS averageRating , SUM(VisitorsPerYear) AS TotalVisitors 
            FROM `tourist_spot` 
            GROUP BY Category
            HAVING averageRating > 4.4
            ORDER BY averageRating DESC" ;
    $result = $conn->query($sql3);

    $sql = "SELECT * FROM `tourist_spot` WHERE 1";

    $result = $conn->query($sql);
    
        while($row = $result->fetch_assoc()) 
        {
            echo " " . $row["SpotID"]. " - " . $row["SpotName"]. " - " . $row["Region"]. " - " . $row["Category"]. " - " . $row["Rating"]. " - " . $row["EntryFee"]. " - " . $row["VisitorsPerYear"]."<br>";
        }


    



     echo "<h3>Query 4</h3>" ;


    $sql4= "SELECT `Region`, SUM(EntryFee*VisitorsPerYear) AS TotalRevenue
            FROM `tourist_spot` 
            GROUP BY Region
            HAVING TotalRevenue > 1000000 
            ORDER BY TotalRevenue DESC" ;
    $result = $conn->query($sql4);   

    $sql = "SELECT * FROM `tourist_spot` WHERE 1";

    $result = $conn->query($sql);
    
        while($row = $result->fetch_assoc()) 
        {
            echo " " . $row["SpotID"]. " - " . $row["SpotName"]. " - " . $row["Region"]. " - " . $row["Category"]. " - " . $row["Rating"]. " - " . $row["EntryFee"]. " - " . $row["VisitorsPerYear"]."<br>";
        }



       




?>