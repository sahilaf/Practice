const weeklyStudyGoal = 20;

let totalHours = 0;
let totalSessions = 0;
let subjects = [];

let subjectInput = document.getElementById("subjectInput");
let hoursInput = document.getElementById("hoursInput");
let addButton = document.getElementById("addButton");
let textDisplay = document.getElementById("labelid");

addButton.addEventListener("click", calculateStudyHours);

function calculateStudyHours() {

    let subjectValue = subjectInput.value.trim();
    let hoursValue = hoursInput.value.trim();

    if (subjectValue === "" || hoursValue === "" ||
        isNaN(Number(hoursValue)) || Number(hoursValue) <= 0) {

        textDisplay.textContent = "Please enter a valid subject and study hours.";
        return;
    }

    totalHours += Number(hoursValue);
    totalSessions++;

    subjects.push(subjectValue);

    let averageHours = totalHours / totalSessions;

    let feedbackMessage;

    if (totalHours <= 5) {
        feedbackMessage = "Start studying regularly!";
    } else if (totalHours <= 12) {
        feedbackMessage = "Good progress!";
    } else if (totalHours < weeklyStudyGoal) {
        feedbackMessage = "Almost ready!";
    } else {
        feedbackMessage = "Weekly goal reached!";
    }

    if (totalSessions > 7 && totalHours < weeklyStudyGoal) {
        feedbackMessage = "Increase your study time!";
    }

    textDisplay.textContent =
        "Total: " + totalHours + " hours" +
        ", Average: " + averageHours + " hours" +
        ", Subjects: [" + subjects.join(", ") + "]" +
        ", " + feedbackMessage;

    subjectInput.value = "";
    hoursInput.value = "";
}
