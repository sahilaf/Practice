<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Spring 2026 Set A</title>
</head>
<body>
    <h1>Student Academic Tracker System </h1>

    <form action="" method="post">
        Credit-earned course : <input type="number" name="creditEarnedPerCourse"> <br> <br>
        Number of completed courses : <input type="number" name="numberOdCopletedCourses"> <br> <br>
        Target graduation credit : <input type="number" name="targetGraduationCredit"> <br> <br> <br> <br>
        
        <button name="submit">Submit</button>
    </form>
    
    <?php

        if(isset($_POST["submit"]))
            {
                $creditEarnedPerCourse = $_POST["creditEarnedPerCourse"] ;
                $numberOdCopletedCourses = $_POST["numberOdCopletedCourses"] ;
                $targetGraduationCredit = $_POST["targetGraduationCredit"] ;
               


                $totalCreditEarned = $creditEarnedPerCourse * $numberOdCopletedCourses ;
                

            
                echo "Total credit earned:  $totalCreditEarned <br>" ;
        

                if ($totalCreditEarned > 120)
                    {
                        $status = "Excellent." ;
                    }
                else if ($totalCreditEarned>=90 && $totalCreditEarned < 120) 
                    {
                        $status = "Good. " ;
                    }
                else if ($totalCreditEarned >= 60 && $totalCreditEarned < 90)
                    {
                        $status = "Average" ;
                    }    
                else if ($totalCreditEarned < 60)
                    {
                        $status = "Poor" ;
                    }    
                echo "$status <br>" ;    


                echo "The target credit number :  $targetGraduationCredit <br>" ;


                if($targetGraduationCredit ==  $totalCreditEarned)
                    {
                        $status = "Equal" ;
                        echo "$status <br>" ;
                    }

                else if($targetGraduationCredit >  $totalCreditEarned)
                    {
                        $status = $targetGraduationCredit - $totalCreditEarned ;
                        echo "Total earned credit is below the graduation credit by :  $status <br>" ;

                    }
                else if($targetGraduationCredit <  $totalCreditEarned)
                    {
                        $status = $totalCreditEarned -  $targetGraduationCredit ;
                        echo "Total earned credit is Above the graduation credit by :  $status <br>" ;

                    }        


            }



    ?>



</body>
</html>