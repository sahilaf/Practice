<?php

    $servername = "localhost"; /// 127.0.0.1
    $username = "root";
    $password = "";
    $dbname = "sundarban";
    $port = "3306" ;
    $conn = new mysqli($servername, $username, $password, $dbname, $port);
    

    if ($conn->connect_error) 
    {
        die("Connection failed: " . $conn->connect_error);
    }
    else 
        {
            echo "<h3>Connection Successfull</h3>" ;
        }




    echo "<h3>Query 1</h3>" ;


    $sql1= "SELECT `CategoryName`, SUM(Revenue) as revenuePerCategory
            FROM `sales_data`
            WHERE 1
            GROUP BY CategoryName " ;
    $result = $conn->query($sql1);

    while($row = $result->fetch_assoc()) 
    {
        echo "Category name: " . $row["CategoryName"]. " - Revenue per category: " . $row["revenuePerCategory"]. " " . "<br>";
    }




    echo "<h3>Query 2</h3>" ;


    $sql2= "UPDATE `sales_data` 
            SET `CategoryName`='Low Performing'
            WHERE Revenue < 40000" ;
    $result = $conn->query($sql2);


   $sql = "SELECT * FROM `sales_data` WHERE 1";

    $result = $conn->query($sql);
    
        while($row = $result->fetch_assoc()) 
        {
            echo " " . $row["SaleID"]. " " . $row["ProductName"]. " " . $row["CategoryID"]. " " . $row["CategoryName"]. " " . $row["Quantity"]. " " . $row["Revenue"]."<br>";
        }




    echo "<h3>Query 3</h3>" ;


    $sql3= "UPDATE `sales_data` 
            SET `Revenue`= (Revenue + (Revenue*0.1))
            WHERE Revenue > 70000" ;
    $result = $conn->query($sql3);

    $sql = "SELECT * FROM `sales_data` WHERE 1";

    $result = $conn->query($sql);
    
        while($row = $result->fetch_assoc()) 
        {
            echo " " . $row["SaleID"]. " " . $row["ProductName"]. " " . $row["CategoryID"]. " " . $row["CategoryName"]. " " . $row["Quantity"]. " " . $row["Revenue"]."<br>";
        }


    


    //  echo "<h3>Query 4</h3>" ;


    // $sql4= "SELECT `DepartmentName` , COUNT(EmployeeID) as Countt FROM `employee_final` GROUP BY DepartmentName ORDER BY Countt DESC" ;
    // $result = $conn->query($sql4);   

    // $sql = "SELECT * FROM `employee_final` WHERE 1";

    // $result = $conn->query($sql);
    
    //     while($row = $result->fetch_assoc()) 
    //     {
    //         echo " " . $row["EmployeeID"]. " " . $row["EmployeeName"]. " " . $row["DepartmentID"]. " " . $row["DepartmentName"]. " " . $row["Salary"]. " " . $row["PerformanceRating"]."<br>";
    //     }



       




?>