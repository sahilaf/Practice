<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Summer 2025</title>
</head>
<body>
    <h1>Movie night event management </h1>

    <form action="" method="post">
        Total number of people attending   : <input type="number" name="totalNumberOfPeopleAttending"> <br> <br>
        Sitting capacity of one screen   : <input type="number" name="sittingCapacityOfOneScreen"> <br> <br>
        Ticket price per seat   : <input type="number" name="ticketPricePerSeat"> <br> <br> <br> <br>

        <button name="submit">Submit</button>
    </form>
    
    <?php

        if(isset($_POST["submit"]))
            {
                $totalNumberOfPeopleAttending = $_POST["totalNumberOfPeopleAttending"] ;
                $sittingCapacityOfOneScreen = $_POST["sittingCapacityOfOneScreen"] ;
                $ticketPricePerSeat = $_POST["ticketPricePerSeat"] ;
               


                $totalScreens = ceil($totalNumberOfPeopleAttending / $sittingCapacityOfOneScreen) ;

                
                echo "Total number of Screens  :  $totalScreens <br>" ;

                $totalSeats = $sittingCapacityOfOneScreen * $totalScreens ;

                $numberOfEmptySeats = $totalSeats - $totalNumberOfPeopleAttending ;

                echo "Total number of Empty seats   :  $numberOfEmptySeats <br>" ;

                $amountWasted = $ticketPricePerSeat * $numberOfEmptySeats ;

                echo "The amount wasted   :  $amountWasted <br>" ;    


            }



    ?>



</body>
</html>