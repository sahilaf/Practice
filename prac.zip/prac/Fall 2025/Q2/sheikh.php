<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Fall 2025</title>
</head>
<body>
    <h1>Event planning system</h1>

    <form action="" method="post">
        Number of items sold per day  : <input type="number" name="numberOfItemsSoldPerDay"> <br> <br>
        Number of days the sale runs  : <input type="number" name="numberOfDaysTheSaleRuns"> <br> <br>
        Target number of items to be sold  : <input type="number" name="targetNumberOfItemsToBeSold"> <br> <br> <br> <br>

        <button name="submit">Submit</button>
    </form>
    
    <?php

        if(isset($_POST["submit"]))
            {
                $numberOfItemsSoldPerDay = $_POST["numberOfItemsSoldPerDay"] ;
                $numberOfDaysTheSaleRuns = $_POST["numberOfDaysTheSaleRuns"] ;
                $targetNumberOfItemsToBeSold = $_POST["targetNumberOfItemsToBeSold"] ;
               


                $totalItemsSold = $numberOfItemsSoldPerDay * $numberOfDaysTheSaleRuns ;
                
            
                echo "Total number of items sold :  $totalItemsSold <br>" ;


                if ($totalItemsSold >= 500)
                    {
                        $status = "Excellent. " ;
                    }
                else if ($totalItemsSold >= 300 && $totalItemsSold < 500) 
                    {
                        $status = "Good " ;
                    }
                else if ($totalItemsSold >= 150 && $totalItemsSold < 300)
                    {
                        $status = "Average " ;
                    }    
                else if ($totalItemsSold < 150)
                    {
                        $status = "Poor" ;
                    }    
                   
                echo "$status <br>" ;
        

                if($targetNumberOfItemsToBeSold ==  $totalItemsSold)
                    {
                        $status = "Target math exactly. (0)" ;
                        echo "$status <br>" ;
                    }

                else if($targetNumberOfItemsToBeSold >  $totalItemsSold)
                    {
                        $status = $targetNumberOfItemsToBeSold - $totalItemsSold ;
                        echo "Below target by :  $status <br>" ;

                    }
                else if($targetNumberOfItemsToBeSold <  $totalItemsSold)
                    {
                        $status = $totalItemsSold -  $targetNumberOfItemsToBeSold ;
                        echo "Above target  by :  $status <br>" ;

                    }     


            }



    ?>



</body>
</html>