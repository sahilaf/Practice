<?php

    $servername = "localhost"; /// 127.0.0.1
    $username = "root";
    $password = "";
    $dbname = "campus_library";
    $port = "3306" ;
    $conn = new mysqli($servername, $username, $password, $dbname, $port);
    

    if ($conn->connect_error) 
    {
        die("Connection failed: " . $conn->connect_error);
    }
    else 
        {
            echo "<h3>Connection Successfull</h3>" ;
        }

    
    echo "<h3>Query 1</h3>" ;


    $sql1= "SELECT `Status` , COUNT(*) AS statusCount
            FROM `book_loans` 
            WHERE 1
            GROUP BY Status
            HAVING statusCount > 1" ;
    $result = $conn->query($sql1);

    while($row = $result->fetch_assoc()) 
    {
        echo "Status: " . $row["Status"]. " - Number of books: " . $row["statusCount"]. " " . "<br>";
    }





    echo "<h3>Query 2</h3>" ;


    $sql2= "UPDATE `book_loans` 
            SET `PenaltyFee`= 0 ,`Status`='Grace period' 
            WHERE Status = 'Overdue' AND DaysOverdue < 7" ;
    $result = $conn->query($sql2);


   $sql = "SELECT * FROM `book_loans` WHERE 1";

    $result = $conn->query($sql);
    
        while($row = $result->fetch_assoc()) 
        {
            echo " " . $row["LoanID"]. " " . $row["StudentName"]. " " . $row["BookTitle"]. " " . $row["DaysOverdue"]. " " . $row["PenaltyFee"]. " " . $row["Status"]."<br>";
        }



    echo "<h3>Query 3</h3>" ;


    $sql3= "UPDATE `book_loans` 
            SET `PenaltyFee`= (PenaltyFee + (PenaltyFee*0.1)) 
            WHERE PenaltyFee > 20 AND (PenaltyFee + (PenaltyFee*0.1)) < 50" ;

    $result = $conn->query($sql3);

    $sql = "SELECT * FROM `book_loans` WHERE 1";

    $result = $conn->query($sql);
    
        while($row = $result->fetch_assoc()) 
        {
            echo " " . $row["LoanID"]. " " . $row["StudentName"]. " " . $row["BookTitle"]. " " . $row["DaysOverdue"]. " " . $row["PenaltyFee"]. " " . $row["Status"]."<br>";
        }


    



     echo "<h3>Query 4</h3>" ;


    $sql4= "SELECT `BookTitle` , SUM(PenaltyFee) AS summation  
            FROM `book_loans` 
            WHERE 1
            GROUP BY BookTitle
            ORDER BY summation DESC" ;
    $result = $conn->query($sql4);   

    while($row = $result->fetch_assoc()) 
    {
        echo "Book title: " . $row["BookTitle"]. " - Summation of penalty fees: " . $row["summation"]. " " . "<br>";
    }


       




?>