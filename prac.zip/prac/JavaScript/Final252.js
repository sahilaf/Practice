const dailyCalorieGoal = 2000; 
 
let totalCalories = 0; 
let totalEntries = 0; 
 
let calorieInput = document.getElementById("calorieInput"); 
let addButton = document.getElementById("addButton"); 
let textDisplay = document.getElementById("labelid"); 
 
addButton.addEventListener("click", calculateCalories); 
 
function calculateCalories() { 
     
    let calorieValue = calorieInput.value.trim(); 
 
    if (calorieValue === "" || isNaN(Number(calorieValue)) || Number(calorieValue) < 0) { 
        textDisplay.textContent = "Please enter a valid calorie amount."; 
        return; 
    } 
 
    totalCalories += Number(calorieValue); 
    totalEntries++; 
 
    let feedbackMessage; 
 
    if (totalEntries > 10 && totalCalories < dailyCalorieGoal) {
        feedbackMessage = "Be cautious of frequent snacking";
    } else if (totalCalories <= 800) { 
        feedbackMessage = "You are off to a healthy start!"; 
    } else if (totalCalories <= 1600) { 
        feedbackMessage = "Good progress, keep it balanced."; 
    } else if (totalCalories < dailyCalorieGoal) { 
        feedbackMessage = "Almost at your limit!"; 
    } else { 
        feedbackMessage = "Goal reached! Stay mindful."; 
    } 
 
    textDisplay.textContent = 
        "Total Calories: " + totalCalories + 
        " / Entries: " + totalEntries + 
        " / Feedback: " + feedbackMessage; 
 
    calorieInput.value = ""; 
}